# CyC Company — resultados del blueprint aprobado

- [ ] Página principal en español, adaptable a móviles y escritorio, reconstruida desde cero con el contenido y recursos visuales del index.html incluido en CyC_Company_Pagina_Web.zip. Incluye navegación funcional entre las secciones y menú accesible en móviles.
- [ ] Identidad y presentación de CyC Company: logotipo suministrado, propuesta de servicio de desbloqueo y liberación de teléfonos, información general del negocio y diseño coherente con los azules, cian y blanco de la fuente.
- [ ] Servicios: desbloqueo de red, revisión de equipos, configuración y orientación, explicando las alternativas disponibles y el proceso antes de comenzar.
- [ ] Información institucional: empresa, misión, visión y objetivo de atención amable, transparente, responsable y confiable en Huatabampo.
- [ ] Listado visual de las marcas de teléfonos presentes en el archivo. La disponibilidad se confirma según el modelo específico, sin promesas no sustentadas.
- [ ] Contacto directo por WhatsApp y llamada al +52 647 220 0387, e indicación para buscar “CyC Company” en Facebook. Consultas de disponibilidad, precio y compatibilidad mediante WhatsApp, sin simular un envío ni un servicio backend.
- [ ] Información de atención visible: Huatabampo Centro, Sonora, México; lunes a domingo con horario a consultar; a domicilio o en local previa confirmación. Sin inventar dirección exacta, horarios, precios o testimonios.
- [ ] Avisos visibles de compatibilidad y legalidad: el servicio depende de equipo, operador y situación legal; no se eliminan bloqueos antirrobo ni se accede a cuentas ajenas.
- [ ] Metadatos comerciales en español, ruta raíz declarada, logotipo de proyecto durable y versión final guardada como checkpoint; Preview operativa sin publicar automáticamente.
